using elearn.Controllers;
using elearn.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;
using Microsoft.EntityFrameworkCore;

namespace UnitTests
{
    public class ProductsTests
    {

        private static DbContextOptions<NorthwindContext> options = new DbContextOptionsBuilder<NorthwindContext>()
                                                                           .UseInMemoryDatabase(Guid.NewGuid().ToString())
                                                                           .Options;

        private static NorthwindContext _context = new NorthwindContext(options);

        private async Task CreateProduct()
        {
            var random = new Random();
            var ProductId = random.Next();
            Product product = new Product();
            product.ProductId = ProductId;
            product.ProductName = Guid.NewGuid().ToString();
            product.CategoryId = 1;
            product.SupplierId = 1;
            await _context.Products.AddAsync(product);
            await _context.SaveChangesAsync();
        }

        [Fact]
        public async Task CreateProductTest()
        {
            var random = new Random();
            var ProductId = random.Next();
            Product product = new Product();
            product.ProductId = ProductId;
            product.ProductName = Guid.NewGuid().ToString();
            product.CategoryId = 1;
            product.SupplierId = 1;
            var controller = new ProductsController(_context);
            var result = await controller.Create(product) as ViewResult;
            var created = await _context.Products.FirstOrDefaultAsync<Product>(m => m.ProductId == ProductId);
            Assert.Equal(product.ProductId, created?.ProductId);
            Assert.Equal(product.ProductName, created?.ProductName);
        }

        [Fact]
        public void CreateProductPageTest()
        {
            var controller = new ProductsController(_context);
            var result = controller.Create() as ViewResult;
            Assert.True(result?.ViewData?.ContainsKey("CategoryId"));
            Assert.True(result?.ViewData?.ContainsKey("SupplierId"));
        }

        [Fact]
        public async Task GetListTest()
        {
            var current = await _context.Products.FirstOrDefaultAsync<Product>(m => m.ProductId > 0);
            if (current == null)
            {
                await CreateProduct();
                current = await _context.Products.FirstOrDefaultAsync<Product>(m => m.ProductId > 0);
            }
            Assert.NotNull(current);
            Assert.NotNull(current?.ProductId);
            var controller = new ProductsController(_context);
            var result = await controller.Index() as Microsoft.AspNetCore.Mvc.ViewResult;
            var products = result?.Model as System.Collections.Generic.List<Product>;
            Assert.True(products?.Count > 0);
        }

        [Fact]
        public async Task GetDetailsTest()
        {
            var current = await _context.Products.FirstOrDefaultAsync<Product>(m => m.ProductId > 0);
            if (current == null)
            {
                await CreateProduct();
                current = await _context.Products.FirstOrDefaultAsync<Product>(m => m.ProductId > 0);
            }
            Assert.NotNull(current);
            Assert.NotNull(current?.ProductId);
            var controller = new ProductsController(_context);
            var result = await controller.Details(current?.ProductId) as ViewResult;
            var product = result?.Model as Product;
            Assert.Equal(current?.ProductId, product?.ProductId);
        }

        [Fact]
        public async Task EditProductPageTest()
        {
            var current = await _context.Products.FirstOrDefaultAsync<Product>(m => m.ProductId > 0);
            if (current == null)
            {
                await CreateProduct();
                current = await _context.Products.FirstOrDefaultAsync<Product>(m => m.ProductId > 0);
            }
            Assert.NotNull(current);
            Assert.NotNull(current?.ProductId);
            var controller = new ProductsController(_context);
            var result = await controller.Edit(current.ProductId) as ViewResult;
            Assert.True(result?.ViewData?.ContainsKey("CategoryId"));
            Assert.True(result?.ViewData?.ContainsKey("SupplierId"));
            var product = result?.Model as Product;
            Assert.Equal(current?.ProductId, product?.ProductId);
        }

        [Fact]
        public async Task EditProductTest()
        {
            var newName = Guid.NewGuid().ToString();
            var current = await _context.Products.FirstOrDefaultAsync<Product>(m => m.ProductId > 0);
            if(current == null)
            {
                await CreateProduct();
                current = await _context.Products.FirstOrDefaultAsync<Product>(m => m.ProductId > 0);
            }
            Assert.NotNull(current);
            Assert.NotNull(current?.ProductId);
            current.ProductName = newName;
            var controller = new ProductsController(_context);
            var result = await controller.Edit(current.ProductId, current) as ViewResult;
            var updated = await _context.Products.FirstOrDefaultAsync<Product>(m => m.ProductId == current.ProductId);
            Assert.Equal(current.ProductId, updated?.ProductId);
            Assert.Equal(newName, updated?.ProductName);
        }

        [Fact]
        public async Task DeleteProductPageTest()
        {
            var exists = await _context.Products.FirstOrDefaultAsync<Product>(m => m.ProductId > 0);
            if (exists == null)
            {
                await CreateProduct();
                exists = await _context.Products.FirstOrDefaultAsync<Product>(m => m.ProductId > 0);
            }
            Assert.NotNull(exists);
            Assert.NotNull(exists?.ProductId);
            var controller = new ProductsController(_context);
            var result = await controller.Edit(exists.ProductId) as ViewResult;
            var product = result?.Model as Product;
            Assert.Equal(exists?.ProductId, product?.ProductId);
        }

        [Fact]
        public async Task DeleteConfirmedTest()
        {
            var controller = new ProductsController(_context);

            var exists = await _context.Products.FirstOrDefaultAsync<Product>(m => m.ProductId > 0);
            if (exists == null)
            {
                await CreateProduct();
                exists = await _context.Products.FirstOrDefaultAsync<Product>(m => m.ProductId > 0);
            }

            Assert.NotNull(exists);
            Assert.NotNull(exists?.ProductId);

            var result = await controller.DeleteConfirmed(exists.ProductId) as ViewResult;
            var deleted = await _context.Products.FirstOrDefaultAsync<Product>(m => m.ProductId == exists.ProductId);
            Assert.Null(deleted);
        }
    }
}