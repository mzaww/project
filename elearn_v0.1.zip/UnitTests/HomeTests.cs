using elearn.Controllers;
using elearn.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace UnitTests
{
    public class HomeTests
    {
        [Fact]
        public void IndexTest()
        {
            var mockLogger = new Mock<ILogger<HomeController>>();
            var controller = new HomeController(mockLogger.Object);
            var result = controller?.Index() as ViewResult;
            Assert.NotNull(result);
        }

        [Fact]
        public void PrivacyTest()
        {
            var mockLogger = new Mock<ILogger<HomeController>>();
            var controller = new HomeController(mockLogger.Object);
            var result = controller?.Privacy() as ViewResult;
            Assert.NotNull(result);
        }

        [Fact]
        public void ErrorTest()
        {
            var mockLogger = new Mock<ILogger<HomeController>>();
            var controller = new HomeController(mockLogger.Object);
            var result = controller?.Error() as ViewResult;
            Assert.NotNull(result);
        }
    }
}